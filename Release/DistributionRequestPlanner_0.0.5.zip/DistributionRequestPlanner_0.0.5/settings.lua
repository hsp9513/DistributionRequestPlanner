data:extend({
	{
		type = "bool-setting",
		name = "requester-override-admin-only",
		setting_type = "runtime-global",
		default_value = true,
		order = 'a-a',
	},
})
